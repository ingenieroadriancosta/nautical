<?php
$admin_name = "admin";
$admin_pass = "1234";

$timesession_sec = (10 * 60);

?>
