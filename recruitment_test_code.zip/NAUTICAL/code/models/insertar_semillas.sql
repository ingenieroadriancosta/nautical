insert into socios( nombres, apellidos, tipo_documento, documento, telefono, celular )
values(
'Adrian', 'Costa', 0, 1234, 3008053163, 3008053163
);
insert into socios( nombres, apellidos, tipo_documento, documento, telefono, celular )
values(
'Jose', 'Medina', 0, 43214325, 3098881212, 3013281212
);
insert into socios( nombres, apellidos, tipo_documento, documento, telefono, celular )
values(
'Jose', 'Martinez', 0, 98761231, 3098543212, 3098143252
);
insert into socios( nombres, apellidos, tipo_documento, documento, telefono, celular )
values(
'Alehana', 'Martinez', 0, 98728231, 3098836712, 3098131212
);
insert into barcos( matricula, nombres, idamarre, costoamarre, id_socios )
values(
12312, 'La martina', 123321, 5000000, 1234
);
insert into operaciones( matricula, fecha_salida, tiempo_salida, destino, idsocios, idcapitanes )
VALUES(
12312, '2020-06-01', '12:00:00', 'Miami', 1234, null
)